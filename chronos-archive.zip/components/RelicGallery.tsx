
import React from 'react';
import { RELIC_DATA } from '../constants';

const RelicGallery: React.FC = () => {
  return (
    <section id="relics" className="py-24 px-6 bg-[#0f1012] border-y border-white/5">
      <div className="max-w-7xl mx-auto">
        <div className="mb-16">
          <h2 className="text-4xl font-serif text-white mb-4">Relics of the Kingdom</h2>
          <p className="text-slate-400 max-w-2xl italic">
            Tangible fragments of the previous epoch. From the Byzantine Christ coinage to the erased technology of the spires.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {RELIC_DATA.map((relic) => (
            <div key={relic.id} className="relative group overflow-hidden rounded-2xl bg-[#16171a] border border-white/5 p-4">
              <div className="aspect-square mb-6 overflow-hidden rounded-xl bg-black">
                <img 
                  src={relic.imageUrl} 
                  alt={relic.title} 
                  className="w-full h-full object-cover transition-all duration-700 opacity-60 group-hover:opacity-100 group-hover:scale-105"
                />
              </div>
              <div className="text-center">
                <span className="text-[10px] text-amber-500 font-bold tracking-[0.2em] uppercase mb-2 block">{relic.year}</span>
                <h3 className="text-xl font-serif text-white mb-2">{relic.title}</h3>
                <p className="text-slate-400 text-sm leading-relaxed">{relic.description}</p>
              </div>
              <div className="absolute inset-x-0 bottom-0 h-1 bg-amber-600 transform scale-x-0 group-hover:scale-x-100 transition-transform duration-500" />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default RelicGallery;
