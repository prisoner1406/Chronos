
import React from 'react';
import { Evidence } from '../types';

interface EvidenceCardProps {
  item: Evidence;
  onAnalyze: (item: Evidence) => void;
}

const EvidenceCard: React.FC<EvidenceCardProps> = ({ item, onAnalyze }) => {
  return (
    <div className="group bg-[#1a1b1e] border border-white/5 rounded-2xl overflow-hidden hover:border-amber-500/30 transition-all duration-500">
      <div className="relative h-64 overflow-hidden">
        <img 
          src={item.imageUrl} 
          alt={item.title} 
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 opacity-80 group-hover:opacity-100"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#1a1b1e] via-transparent to-transparent opacity-60" />
        <div className="absolute top-4 left-4 bg-amber-600/90 text-white text-[10px] px-3 py-1 rounded-full uppercase font-bold tracking-widest backdrop-blur-sm">
          {item.category}
        </div>
        <div className="absolute bottom-4 left-4 flex flex-col">
          <span className="text-amber-500 font-serif text-xs italic">{item.year}</span>
          <span className="text-white font-serif text-lg leading-tight">{item.location}</span>
        </div>
      </div>
      <div className="p-6">
        <h3 className="text-xl font-serif text-slate-100 mb-3 group-hover:text-amber-400 transition-colors">
          {item.title}
        </h3>
        <p className="text-slate-400 text-sm leading-relaxed line-clamp-3">
          {item.description}
        </p>
        <div className="mt-6 flex items-center gap-2">
          <div className="h-px flex-1 bg-white/5" />
          <button 
            onClick={() => onAnalyze(item)}
            className="text-[10px] uppercase tracking-widest text-amber-500/70 hover:text-amber-400 font-bold transition-colors py-2 px-4 rounded-lg border border-transparent hover:border-amber-500/20"
          >
            Analyze Data →
          </button>
        </div>
      </div>
    </div>
  );
};

export default EvidenceCard;
