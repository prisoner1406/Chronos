
import React from 'react';
import { Section } from '../types';

interface NavigationProps {
  onNavigate: (section: Section) => void;
}

const Navigation: React.FC<NavigationProps> = ({ onNavigate }) => {
  return (
    <nav className="fixed top-0 left-0 w-full z-50 bg-[#0f1012]/80 backdrop-blur-md border-b border-white/10 px-6 py-4">
      <div className="max-w-7xl mx-auto flex justify-between items-center">
        <div 
          className="flex items-center gap-3 cursor-pointer group"
          onClick={() => onNavigate(Section.HERO)}
        >
          <div className="w-10 h-10 bg-amber-500/10 border border-amber-500/30 rounded-full flex items-center justify-center group-hover:bg-amber-500/20 transition-all">
            <span className="text-amber-500 font-serif text-xl">Ω</span>
          </div>
          <span className="text-xl font-serif tracking-widest uppercase text-amber-500/90 group-hover:text-amber-400 transition-colors">Chronos Archive</span>
        </div>
        
        <div className="hidden lg:flex items-center gap-8">
          {[
            { label: 'Archive', id: Section.EVIDENCE },
            { label: 'Relics', id: Section.RELICS },
            { label: 'Timeline', id: Section.TIMELINE },
            { label: 'AI Investigator', id: Section.AI_ORACLE },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className="text-sm font-medium tracking-widest uppercase text-slate-400 hover:text-amber-500 transition-colors"
            >
              {item.label}
            </button>
          ))}
        </div>

        <button 
          onClick={() => onNavigate(Section.AI_ORACLE)}
          className="bg-amber-600 hover:bg-amber-500 text-white text-xs px-5 py-2 rounded-full uppercase tracking-tighter transition-all font-bold shadow-lg shadow-amber-900/20"
        >
          Begin Inquiry
        </button>
      </div>
    </nav>
  );
};

export default Navigation;
