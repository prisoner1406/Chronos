
import React, { useState, useRef, useEffect } from 'react';
import { Message } from '../types';
import { askInvestigator } from '../services/geminiService';

interface AIInvestigatorProps {
  initialQuery?: string | null;
  onQueryHandled?: () => void;
}

const AIInvestigator: React.FC<AIInvestigatorProps> = ({ initialQuery, onQueryHandled }) => {
  const [messages, setMessages] = useState<Message[]>([
    { role: 'assistant', content: "Welcome, seeker of truth. I am the Chronos Investigator. What anomalies of our timeline shall we examine today? The World Fairs? The Mud Flood? Or perhaps the nature of the Little Season?" }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  useEffect(() => {
    if (initialQuery) {
      handleSend(initialQuery);
      if (onQueryHandled) onQueryHandled();
    }
  }, [initialQuery]);

  const handleSend = async (queryToUse?: string) => {
    const textToSubmit = queryToUse || input;
    if (!textToSubmit.trim() || isTyping) return;

    const userMessage: Message = { role: 'user', content: textToSubmit };
    setMessages(prev => [...prev, userMessage]);
    if (!queryToUse) setInput('');
    setIsTyping(true);

    const response = await askInvestigator(textToSubmit);
    
    setMessages(prev => [...prev, { role: 'assistant', content: response }]);
    setIsTyping(false);
  };

  return (
    <section id="oracle" className="py-24 px-6 bg-[#0f1012]">
      <div className="max-w-5xl mx-auto border border-amber-500/20 rounded-3xl overflow-hidden bg-[#16171a] shadow-2xl shadow-black">
        <div className="p-6 border-b border-white/5 bg-amber-500/5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-amber-500 rounded-2xl flex items-center justify-center text-black font-serif text-2xl rotate-3">
              ?
            </div>
            <div>
              <h2 className="text-xl font-serif text-white leading-none">AI Investigator</h2>
              <span className="text-[10px] text-amber-500 uppercase tracking-widest font-bold">Chronos Archive Protocol</span>
            </div>
          </div>
          <div className="hidden md:block text-right">
            <span className="text-[10px] text-slate-500 uppercase tracking-widest block">Access Level</span>
            <span className="text-white font-mono text-xs">UNRESTRICTED_QUERY</span>
          </div>
        </div>

        <div 
          ref={scrollRef}
          className="h-[500px] overflow-y-auto p-8 space-y-6 scroll-smooth"
        >
          {messages.map((msg, i) => (
            <div 
              key={i} 
              className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`max-w-[85%] p-4 rounded-2xl ${
                msg.role === 'user' 
                ? 'bg-amber-600 text-white rounded-tr-none' 
                : 'bg-white/5 text-slate-200 border border-white/5 rounded-tl-none'
              }`}>
                <div className="text-sm leading-relaxed prose prose-invert prose-amber max-w-none">
                  {msg.content.split('\n').map((line, idx) => (
                    <p key={idx} className="mb-2 last:mb-0">{line}</p>
                  ))}
                </div>
              </div>
            </div>
          ))}
          {isTyping && (
            <div className="flex justify-start">
              <div className="bg-white/5 p-4 rounded-2xl flex gap-1 items-center">
                <div className="w-1 h-1 bg-amber-500 rounded-full animate-bounce" />
                <div className="w-1 h-1 bg-amber-500 rounded-full animate-bounce [animation-delay:0.2s]" />
                <div className="w-1 h-1 bg-amber-500 rounded-full animate-bounce [animation-delay:0.4s]" />
              </div>
            </div>
          )}
        </div>

        <div className="p-6 bg-[#0f1012] border-t border-white/5">
          <div className="relative flex gap-3">
            <input 
              type="text" 
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Ask about the World Fairs, Antiquitech, or the Little Season..."
              className="flex-1 bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-amber-500/50 transition-colors"
            />
            <button 
              onClick={() => handleSend()}
              disabled={isTyping || !input.trim()}
              className="bg-amber-600 hover:bg-amber-500 disabled:opacity-50 disabled:hover:bg-amber-600 text-white px-6 py-3 rounded-xl font-bold uppercase tracking-widest text-xs transition-all shadow-lg shadow-amber-900/10"
            >
              Consult
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AIInvestigator;
