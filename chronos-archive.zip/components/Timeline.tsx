
import React from 'react';

const TimelineStep: React.FC<{ 
  title: string; 
  date: string; 
  description: string; 
  active?: boolean 
}> = ({ title, date, description, active }) => (
  <div className={`relative pl-8 pb-12 last:pb-0 border-l ${active ? 'border-amber-500' : 'border-white/10'}`}>
    <div className={`absolute -left-2 top-0 w-4 h-4 rounded-full border-2 ${active ? 'bg-amber-500 border-amber-500 animate-pulse' : 'bg-[#0f1012] border-white/20'}`} />
    <div className="flex flex-col gap-1">
      <span className={`text-[10px] uppercase tracking-widest font-bold ${active ? 'text-amber-500' : 'text-slate-500'}`}>{date}</span>
      <h4 className="text-lg font-serif text-slate-100">{title}</h4>
      <p className="text-sm text-slate-400 leading-relaxed max-w-xl">{description}</p>
    </div>
  </div>
);

const Timeline: React.FC = () => {
  return (
    <section id="timeline" className="py-24 px-6 bg-[#0a0b0d]">
      <div className="max-w-4xl mx-auto">
        <div className="mb-16 text-center">
          <h2 className="text-4xl md:text-5xl font-serif text-white mb-4">The Chronological Distortion</h2>
          <p className="text-slate-400 max-w-2xl mx-auto italic">
            "For a thousand years in thy sight are but as yesterday when it is past..." 
            Tracing the start from Nero to the "Independence" reset.
          </p>
        </div>

        <div className="space-y-4">
          <TimelineStep 
            date="~70 AD - ~1776 AD"
            title="The Millennial Reign (The Iesus Era)"
            description="The true 1,000-year reign following the Judgment of Jerusalem and the fall of Nero. An era of unified civilization and advanced Antiquitech. Historical records used 'I' or 'J' (e.g., J750) to denote years of the King's reign."
          />
          <TimelineStep 
            date="July 4th, 1776"
            title="Declaration of 'Independence'"
            description="The symbolic end of the Kingdom era. Adversarial forces declare 'Independence' from the divine order, marking the point where the adversary is 'loosed' for a little season. 1776 marks a spiritual and chronological pivot point."
          />
          <TimelineStep 
            date="1777 - 1850 AD"
            title="The Reset & The Mud Flood"
            description="A period of global cataclysm used to wipe the physical slate. The '1' replaces the 'I' in historical dating to extend the timeline by 1,000 years, pushing the Kingdom back into 'ancient history' and hiding its recent existence."
          />
          <TimelineStep 
            date="1851 - 1914 AD"
            title="The Redaction (The World Fairs)"
            description="The new orphan populations are shown the ruins of the Kingdom (labeled as 'temporary' pavilions) at World Fairs before they are demolished. History is rewritten to frame this architecture as 'Classical' or 'Victorian'."
          />
          <TimelineStep 
            date="1914 AD - Present"
            title="Satan's Little Season"
            active
            description="The era of total concealment. Technology remnants are classified as 'UAPs' and the true 1,000-year reign of Christ is treated as a myth or a future event rather than a past reality."
          />
        </div>
      </div>
    </section>
  );
};

export default Timeline;
