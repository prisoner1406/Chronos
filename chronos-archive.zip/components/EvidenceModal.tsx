
import React from 'react';
import { Evidence } from '../types';

interface EvidenceModalProps {
  item: Evidence | null;
  onClose: () => void;
  onAskAI: (query: string) => void;
}

const EvidenceModal: React.FC<EvidenceModalProps> = ({ item, onClose, onAskAI }) => {
  if (!item) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 md:p-8">
      <div 
        className="absolute inset-0 bg-black/95 backdrop-blur-xl" 
        onClick={onClose}
      />
      
      <div className="relative bg-[#0d0e11] border border-amber-600/40 w-full max-w-6xl max-h-[95vh] overflow-y-auto rounded-none md:rounded-[40px] shadow-[0_0_50px_rgba(217,119,6,0.1)] flex flex-col md:flex-row border-double">
        {/* Close Button */}
        <button 
          onClick={onClose}
          className="absolute top-8 right-8 z-50 w-12 h-12 bg-black/80 hover:bg-amber-600 rounded-full flex items-center justify-center text-white transition-all border border-amber-500/30 group"
        >
          <span className="group-hover:rotate-90 transition-transform">✕</span>
        </button>

        {/* Visual Proof */}
        <div className="md:w-3/5 bg-black min-h-[400px] relative overflow-hidden flex items-center justify-center border-r border-amber-900/20">
          <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-20 pointer-events-none" />
          <img 
            src={item.imageUrl} 
            alt={item.title} 
            className="w-full h-full object-cover md:object-contain relative z-10"
          />
          <div className="absolute top-6 left-6 z-20 flex gap-2">
            <span className="bg-amber-600/90 text-[9px] px-3 py-1 font-bold uppercase tracking-widest text-white backdrop-blur-md">AUTHENTICATED_FILE</span>
            <span className="bg-black/80 text-[9px] px-3 py-1 font-mono text-amber-500/80 backdrop-blur-md border border-amber-500/20">IMG_SOURCE: {item.category}</span>
          </div>
          <div className="absolute bottom-6 left-6 z-20">
             <div className="flex items-center gap-3">
                <div className="w-2 h-2 bg-red-600 rounded-full animate-pulse" />
                <span className="text-white font-mono text-[10px] tracking-tighter">DATA_STREAM: ACTIVE</span>
             </div>
          </div>
        </div>

        {/* Analysis Details */}
        <div className="md:w-2/5 p-8 md:p-14 flex flex-col justify-center bg-[#0d0e11]">
          <div className="flex items-center gap-2 mb-6">
            <div className="h-px w-8 bg-amber-500/50" />
            <span className="text-amber-500 font-bold uppercase tracking-[0.4em] text-[10px]">Case Archive: {item.year}</span>
          </div>
          
          <h2 className="text-4xl md:text-5xl font-serif text-white mb-8 leading-tight decoration-amber-600 underline-offset-8 underline decoration-1">
            {item.title}
          </h2>
          
          <div className="space-y-6 mb-12">
            <p className="text-slate-300 leading-relaxed text-lg font-light">
              {item.description}
            </p>
            <div className="p-6 bg-amber-500/5 border border-amber-500/10 rounded-2xl italic text-slate-400 text-sm relative overflow-hidden group">
               <div className="absolute top-0 left-0 w-1 h-full bg-amber-600" />
              "The architectural and atmospheric data suggests a technology level suppressed by the 19th-century 'Great Reset' and subsequently hidden by agencies of the Little Season."
            </div>
          </div>

          <div className="mt-auto space-y-4">
            <button 
              onClick={() => onAskAI(`Investigate the hidden details of ${item.title}. Relate it to the Millennial Kingdom and the modern institutional cover-up.`)}
              className="w-full bg-amber-600 hover:bg-amber-500 text-white font-bold py-5 rounded-none md:rounded-2xl uppercase tracking-[0.3em] text-[10px] transition-all shadow-xl shadow-amber-900/30 active:scale-[0.98]"
            >
              Consult AI Investigator
            </button>
            <div className="flex gap-4">
               <button 
                onClick={onClose}
                className="flex-1 border border-white/10 hover:border-amber-500/30 hover:bg-white/5 text-slate-500 hover:text-amber-500 font-bold py-4 rounded-none md:rounded-2xl uppercase tracking-[0.2em] text-[9px] transition-all"
              >
                Close File
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EvidenceModal;
